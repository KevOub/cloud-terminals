the password is the current working directory
