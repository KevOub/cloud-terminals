#!/bin/bash

CURRENTHASH=$(find /home/ -type f | grep -v cyber | xargs -i  sh -c 'cat {} && echo {}'  | md5sum | cut -d' ' -f1)
BENCHMARKHASH=$(cat /root/home_checksum)

if [ $CURRENTHASH == $BENCHMARKHASH ]; then
    exit 0
else
    exit 1
fi