Hopefully you are now confident moving around directories

The password for level5 is:
i_can_do_this

