You get a flag for reading this file!


The password for level2 is:
good_cat
