Remember this lesson

The password for level4 is:
periods_do_not_protect_you

