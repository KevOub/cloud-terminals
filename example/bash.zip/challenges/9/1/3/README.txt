Is linux *that* bad?

The password for level5 is:     scavenger_skill_increase
