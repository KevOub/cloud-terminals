You are progressing well

The password for level3 is:
phonehome_directory
