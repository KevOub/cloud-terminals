#!/bin/bash

# cyber is the local admin that can read and reset all flags

########### ########### 
# 1) Add user 
# 2) Copy from /home/cyber to /home/level1
# 3) copy the sample bashrc file over so first login shows 
#
########### ########### 

PERMISSIONSLEVEL=750
USERLEVEL=1001
LEVEL=1
PASSWORDLEVEL="level1"

function make_level(){
    useradd -rm -d /home/level$LEVEL -s /bin/bash -u $USERLEVEL level$LEVEL
    touch /home/level$LEVEL/.hushlogin # turns off hello message
    echo "level$LEVEL:$PASSWORDLEVEL" | chpasswd
    rsync -av /root/$LEVEL/* /home/level$LEVEL/
    echo "echo $CHALLENGEMESSAGE" >> /home/level$LEVEL/.bashrc

    chmod -R $PERMISSIONSLEVEL /home/level$LEVEL/ 
    chown -R level$LEVEL /home/level$LEVEL/
    LEVEL=$(( $LEVEL+1 ))
    USERLEVEL=$(( $USERLEVEL+1 ))

}

####
# Level 1:
#   read README.txt with cat
# Password:
#   level1
####
CHALLENGEMESSAGE="Can you read that message in front of you?"
PASSWORDLEVEL="level1"
make_level


####
# Level 2:
#   change directory and then read README.txt with cat
# Password:
#   good_cat
####
CHALLENGEMESSAGE="Interesting. The flag is in that directory. Can you go into that directory and read that message?"
PASSWORDLEVEL="good_cat"
make_level

####
# Level 3:
#   Hidden directory because of a period
# Password:
#   phonehome_directory
####
CHALLENGEMESSAGE="Did you know that you can hide files in Linux? Just add a period in front! Find the hidden file to get to the next level"
PASSWORDLEVEL="phonehome_directory"
make_level
mv /home/level3/README.txt /home/level3/.README.txt


####
# Level 4:
#   Forcing finding directories through bruteforce
# Password:
#   periods_do_not_protect_you
#   
####
CHALLENGEMESSAGE="OK you want a real test. There are several folders and several ways to find the flag. Good luck "
PASSWORDLEVEL="periods_do_not_protect_you"
make_level

####
# Level 5:
#   Introduce `pwd` 
# Password:
#   digging_deep
#   
####
CHALLENGEMESSAGE="Now for an easier challenge. The password for the next level is the current directory "
PASSWORDLEVEL="digging_deep"
make_level


####
# Level 6:
#   Another easy question 
# Password:
#   /home/level5
#   
####
CHALLENGEMESSAGE="Do not get a head of yourself now. The password is still in README.txt, but it is at the 100th line"
PASSWORDLEVEL="/home/level5"
make_level


####
# Level 7:
#   First grep lesson 
# Password:
#   baklava
#   
####
CHALLENGEMESSAGE="Linux comes installed with a tool to search files for patterns called grep. Example usage is in the `grep_cheatsheet`. Use it to figure out what is the only word in the README.txt file that contains the letter 'u'. That is the password for level 8"
PASSWORDLEVEL="baklava"
make_level

####
# Level 8:
#   Second grep lesson 
# Password:
#   ducks
#   
####
CHALLENGEMESSAGE="So you know about the ducks. What word comes 5 words before 'ducks'? A little hint is the ducks probably would eat it "
PASSWORDLEVEL="ducks"
make_level


####
# Level 9 :
#   Hinting at there is an easier way
# Password:
#   crabgrass
####
CHALLENGEMESSAGE="To prevent digging through 90 levels of directories, know the word password appears in the file. I recommend reading about recursion and grep... "
PASSWORDLEVEL="crabgrass"
make_level


####
# Level 10 :
#   Introduce pipes
# Password:
#   scavenger_skill_increase
####
CHALLENGEMESSAGE="What makes linux fun is pipes. Any output can be sent over to another command with them! For an example, count the number of lines in the README.txt file"
PASSWORDLEVEL="scavenger_skill_increase"
make_level


####
# Level 11 :
#   Combine skills into one
# Password:
#   scavenger_skill_increase
####
CHALLENGEMESSAGE="Now, combine your knowledge of grep, wc, and pipes to count the number of lines that contain the pattern of cyber"
PASSWORDLEVEL="25322"
make_level


# 25322 times

#   scavenger_skill_increase
